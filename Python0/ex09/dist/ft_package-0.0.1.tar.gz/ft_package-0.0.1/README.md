
# ft_package

A sample test package for 42 exercise.
